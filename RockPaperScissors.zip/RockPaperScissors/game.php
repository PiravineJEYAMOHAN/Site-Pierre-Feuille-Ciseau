<!DOCTYPE html>
<html>
<head>
	<title>Jeu de pierre-feuille-ciseaux</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="game-container">
		<div class = "enemy-name-box">
			<h2 id="enemy-name"> Ordinateur </h2>
		</div>
		<div class="enemy-box">
			<div id="enemy-game" class="game"> 

			</div>
		</div>
		<div class="game-box">
			<div id ="game" class="game">
				<button id = "rock-btn" class = "rock" onclick="play('Pierre')"></button>
				<button id = "paper-btn" class = "paper" onclick="play('Feuille')"></button>
				<button id = "scissors-btn" class = "scissors" onclick="play('Ciseaux')"></button>
			</div>
		</div>
		<div class="result-container">
			<p id="result"></p>
		</div>
		<div class="elo-box">
			<h2>Elo</h2>
			<p id="elo">0</p>
		</div>
		<button class="toggle-theme">Mode sombre temporaire</button>
	</div>
	<script type="text/javascript" src="script/script.js"></script>
</body>
</html>