
<!-- PAGE PROFIL UTILISATEUR -->

<?php 
	if(!isset($_SESSION)){ 
        session_start(); 
    }

    if(!isset($_SESSION['role'])){ 
        print_r($_POST['role']);
        header('Location: Authentifier.php'); // Renvoie à la page connexion
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
</head>
<body>
<?php  include("entete.php"); ?>

<div class="container">	
    <?php 
        include_once("ConnectMySQl.php");

        // Récupération des données de l'utilisateur

        // !!!!!!!!! NOMS DONNEES A CHANGER SELON CEUX DE LA BASE DE DONNEES !!!!!!!!

        $user_id = $_SESSION["user_id"]; // Récupération de l'ID de l'utilisateur à partir de la session
        $sql = "SELECT * FROM user WHERE id = $user_id";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            // Affichage des données de l'utilisateur
            $row = mysqli_fetch_assoc($result);
            echo "Nom : " . $row["nom"] . "<br>";
            echo "Pseudo : " . $row["pseudo"] . "<br>";
            echo "Email : " . $row["email"];
        }
    ?>
</div>
    
</body>
</html>