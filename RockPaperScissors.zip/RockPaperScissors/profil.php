
<!-- PAGE PROFIL UTILISATEUR -->

<?php 
	if(!isset($_SESSION)){ 
        session_start(); 
    }

    if(!isset($_SESSION['role'])){ 
        print_r($_POST['role']);
        header('Location: Authentifier.php'); // Pas connecté et renvoie à la page connexion
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <title>Profil</title>
    <style>
      .box {
        display: flex;
        align-items: center;
        margin-top: 10px;
        width: 500px;
        height: 250px;
        justify-content: center;
        border: 2px solid #000000;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        margin-bottom: 15px;
        flex-direction: column;
      }
    </style>
</head>
<body>
    <?php  include("entete.php"); ?>
    <div class="game-container">
        <div class ="box">
            <h2>Profil</h2>
            <p>Pseudo : Jean128 </p>
            <p>Email : jean@gmail.com</p>
        </div>
        <div class="box">
            <h2>Statistiques</h2>
            <p>Elo : 0</p>
            <p>Victoires : 0</p>
            <p>Defaites : 0</p>
            <p>Egalités : 0</p>
        </div>
    </div>
</body>
</html>